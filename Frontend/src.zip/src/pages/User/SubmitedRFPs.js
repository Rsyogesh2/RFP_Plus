import React from 'react'

const SubmitedRFPs = () => {
  return (
    <div>SubmitedRFPs</div>
  )
}

export default SubmitedRFPs