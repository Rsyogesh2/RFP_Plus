let ok={ 
    "l1": [
      {
        "name": "Loan management services",
        "code": 50,
        "l2": [
          {
            "name": "Product master",
            "code": "5010",
            "l3": [
              {
                "name": "Basic loan product creation",
                "code": "501010"
              },
              {
                "name": "Fee management",
                "code": "501011"
              },
              {
                "name": "Interest management",
                "code": "501012"
              },
              {
                "name": "NPA management",
                "code": "501013"
              },
              {
                "name": "Accounting",
                "code": "501014"
              }
            ]
          },
          {
            "name": "Loan disbursement",
            "code": "5011",
            "l3": []
          },
          {
            "name": "Amortization schedule",
            "code": "5012",
            "l3": []
          },
          {
            "name": "Loan servicing",
            "code": "5013",
            "l3": [
              {
                "name": "Repayment handling",
                "code": "501310"
              },
              {
                "name": "Loan modifications",
                "code": "501311"
              },
              {
                "name": "Backend processing",
                "code": "501312"
              },
              {
                "name": "Queries & Reports",
                "code": "501313"
              }
            ]
          },
          {
            "name": "Loan management services - Others",
            "code": "5099",
            "l3": []
          }
        ]
      }
    ]
  }