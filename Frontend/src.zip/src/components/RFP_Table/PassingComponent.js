import React from 'react'

export default function PassingComponent({items}) {
  return (
    <div>{items}</div>
  )
}
